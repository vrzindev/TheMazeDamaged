# O que será utilizado:
* Scanner;
* Random (Para gerar os mapas aleatoriamente);
* Estrutura De Repetição (While e talvez for e do while);
* Estrutura Condicional (IF, Else, Else IF);
* Funções;
* Classes Separadas Para Cada Método (private static void).
* Boolean ( Para Verificar as condições e decidir posteriormente o caminho do jogador).
* Char (Para Detectar os caracteres).


# Pendencias / Bugs:
* Como fazer um final do mapa e ir para outro mapa no random;
* Estudar o que será utilizado;
* Arrumar a documentação, tirando a perca de jogo por tempo, deixando apenas o limite de movimentação;
* Pensar em como utilizar o Random para gerar inimigos (Obrigatorio, diferencial do game); [Tomorrow]
* Pensar como o usuário poderia reagir para escapar ou combater o inimigo, lembrando que suas ações resultaram na perca de movimentos, dificultando ainda mais a vitória conforme as fases, pois a intensidade do Random ao criar inimigos precisa ser aumentada conforme a evolução do jogador. [Tomorrow]
* Pensar em 3 mapas e contar o numero de passos de cada mapa.[Tomorrow]
* Pensar em como fazer o inimigo spawnando no mapa.[Tomorrow]
* Colocar As Informações Do Jogador/Jogo Em formato organizado ou de tabela.[Tomorrow]


# Descartes ou já feitos [X - Descartado], [V - Feito]:

* Como aumentar o mapa no terminal [X]
* Menu de inicio [V] 
* 





# Adicionado Para (20/05/24):

* Menu Editável contendo: Escolha Do Nome Do Jogador, Dificuldade, Personagem.
* Cores Utilizando códigos de escape ANSI.







